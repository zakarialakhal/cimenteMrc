import { useState, useEffect } from 'react';
import { useToast } from '@/components/ui/use-toast';

const initialFormData = {
  requestingDepartment: '',
  supervisorName: '',
  eventDate: '',
  eventTime: '',
  eventLocation: '',
  eventPurpose: '',
  guests: [{ name: '', isInternal: true, organization: '' }],
  mealsCount: 1,
  dessertsCount: 0,
  softDrinksCount: 0,
  hotBeveragesCount: 0,
  specialRequests: ''
};

export const useMealRequests = () => {
  const [requests, setRequests] = useState(() => {
    try {
      const savedRequests = localStorage.getItem('mealRequests');
      if (savedRequests) {
        const parsedRequests = JSON.parse(savedRequests);
        return Array.isArray(parsedRequests) ? parsedRequests : [];
      }
      return [];
    } catch (error) {
      console.error("Failed to parse meal requests from localStorage", error);
      return [];
    }
  });

  const [formData, setFormData] = useState(initialFormData);
  const [editingRequest, setEditingRequest] = useState(null);
  const { toast } = useToast();

  useEffect(() => {
    try {
      localStorage.setItem('mealRequests', JSON.stringify(requests));
    } catch (error) {
      console.error("Failed to save meal requests to localStorage", error);
      toast({
        title: "Storage Error",
        description: "Could not save your changes.",
        variant: "destructive"
      });
    }
  }, [requests]);

  const resetForm = () => {
    setFormData(initialFormData);
    setEditingRequest(null);
  };

  const handleInputChange = (field, value) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleGuestChange = (index, field, value) => {
    const updatedGuests = [...formData.guests];
    updatedGuests[index] = { ...updatedGuests[index], [field]: value };
    setFormData(prev => ({ ...prev, guests: updatedGuests }));
  };

  const addGuest = () => {
    setFormData(prev => ({
      ...prev,
      guests: [...prev.guests, { name: '', isInternal: true, organization: '' }]
    }));
  };

  const removeGuest = (index) => {
    if (formData.guests.length > 1) {
      const updatedGuests = formData.guests.filter((_, i) => i !== index);
      setFormData(prev => ({ ...prev, guests: updatedGuests }));
    }
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    
    if (!formData.requestingDepartment || !formData.supervisorName || !formData.eventDate) {
      toast({
        title: "Missing Information",
        description: "Please fill in all required fields.",
        variant: "destructive"
      });
      return false;
    }

    const newRequest = {
      id: editingRequest ? editingRequest.id : Date.now().toString(),
      ...formData,
      status: editingRequest ? editingRequest.status : 'pending',
      submittedAt: editingRequest ? editingRequest.submittedAt : new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };

    if (editingRequest) {
      setRequests(prev => prev.map(req => req.id === editingRequest.id ? newRequest : req));
      toast({
        title: "Request Updated",
        description: "Your meal request has been updated successfully!",
      });
    } else {
      setRequests(prev => [newRequest, ...prev]);
      toast({
        title: "Request Submitted",
        description: "Your meal request has been submitted to the restaurant manager!",
      });
    }

    resetForm();
    return true;
  };

  const handleEdit = (request) => {
    if (request.status !== 'pending') {
      toast({
        title: "Cannot Edit",
        description: "Only pending requests can be modified.",
        variant: "destructive"
      });
      return;
    }
    setEditingRequest(request);
    setFormData(request);
  };

  const handleDelete = (requestId) => {
    const request = requests.find(r => r.id === requestId);
    if (request.status !== 'pending') {
      toast({
        title: "Cannot Delete",
        description: "Only pending requests can be deleted.",
        variant: "destructive"
      });
      return;
    }
    setRequests(prev => prev.filter(req => req.id !== requestId));
    toast({
      title: "Request Deleted",
      description: "The meal request has been deleted.",
    });
  };

  const handleStatusChange = (requestId, newStatus) => {
    setRequests(prev => prev.map(req => 
      req.id === requestId 
        ? { ...req, status: newStatus, updatedAt: new Date().toISOString() }
        : req
    ));
    
    const statusMessages = {
      approved: "Request has been approved!",
      rejected: "Request has been rejected.",
    };
    
    toast({
      title: "Status Updated",
      description: statusMessages[newStatus],
    });
  };

  const stats = {
    total: requests.length,
    pending: requests.filter(r => r.status === 'pending').length,
    approved: requests.filter(r => r.status === 'approved').length,
    rejected: requests.filter(r => r.status === 'rejected').length
  };

  return {
    requests,
    formData,
    editingRequest,
    stats,
    resetForm,
    handleInputChange,
    handleGuestChange,
    addGuest,
    removeGuest,
    handleSubmit,
    handleEdit,
    handleDelete,
    handleStatusChange,
    setEditingRequest,
  };
};
import React, { useState, useEffect } from 'react';
import { useToast } from '@/components/ui/use-toast';

const INITIAL_FORM_DATA = {
  requestingDepartment: '',
  supervisorName: '',
  eventDate: '',
  eventTime: '',
  eventLocation: '',
  eventPurpose: '',
  guests: [{ name: '', isInternal: true, organization: '' }],
  mealsCount: 1,
  dessertsCount: 0,
  softDrinksCount: 0,
  hotBeveragesCount: 0,
  specialRequests: ''
};

export const useRequests = () => {
  const [requests, setRequests] = useState([]);
  const [formData, setFormData] = useState(INITIAL_FORM_DATA);
  const { toast } = useToast();

  useEffect(() => {
    try {
      const savedRequests = localStorage.getItem('mealRequests');
      if (savedRequests) {
        setRequests(JSON.parse(savedRequests));
      }
    } catch (error) {
      console.error("Failed to parse meal requests from localStorage", error);
      setRequests([]);
    }
  }, []);

  useEffect(() => {
    localStorage.setItem('mealRequests', JSON.stringify(requests));
  }, [requests]);

  const resetForm = () => {
    setFormData(INITIAL_FORM_DATA);
  };

  const handleInputChange = (field, value) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleGuestChange = (index, field, value) => {
    const updatedGuests = [...formData.guests];
    updatedGuests[index] = { ...updatedGuests[index], [field]: value };
    setFormData(prev => ({ ...prev, guests: updatedGuests }));
  };

  const addGuest = () => {
    setFormData(prev => ({
      ...prev,
      guests: [...prev.guests, { name: '', isInternal: true, organization: '' }]
    }));
  };

  const removeGuest = (index) => {
    if (formData.guests.length > 1) {
      const updatedGuests = formData.guests.filter((_, i) => i !== index);
      setFormData(prev => ({ ...prev, guests: updatedGuests }));
    }
  };

  const handleSubmit = (editingRequest) => {
    if (!formData.requestingDepartment || !formData.supervisorName || !formData.eventDate) {
      toast({
        title: "Missing Information",
        description: "Please fill in all required fields.",
        variant: "destructive"
      });
      return false;
    }

    const newRequest = {
      id: editingRequest ? editingRequest.id : Date.now().toString(),
      ...formData,
      status: editingRequest ? editingRequest.status : 'pending',
      submittedAt: editingRequest ? editingRequest.submittedAt : new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };

    if (editingRequest) {
      setRequests(prev => prev.map(req => req.id === editingRequest.id ? newRequest : req));
      toast({
        title: "Request Updated",
        description: "Your meal request has been updated successfully!",
      });
    } else {
      setRequests(prev => [newRequest, ...prev]);
      toast({
        title: "Request Submitted",
        description: "Your meal request has been submitted to the restaurant manager!",
      });
    }

    resetForm();
    return true;
  };

  const handleDelete = (requestId) => {
    const request = requests.find(r => r.id === requestId);
    if (request.status !== 'pending') {
      toast({
        title: "Cannot Delete",
        description: "Only pending requests can be deleted.",
        variant: "destructive"
      });
      return;
    }
    setRequests(prev => prev.filter(req => req.id !== requestId));
    toast({
      title: "Request Deleted",
      description: "The meal request has been deleted.",
    });
  };

  const handleStatusChange = (requestId, newStatus) => {
    setRequests(prev => prev.map(req => 
      req.id === requestId 
        ? { ...req, status: newStatus, updatedAt: new Date().toISOString() }
        : req
    ));
    
    const statusMessages = {
      approved: "Request has been approved!",
      rejected: "Request has been rejected.",
    };
    
    toast({
      title: "Status Updated",
      description: statusMessages[newStatus],
    });
  };

  return {
    requests,
    formData,
    setFormData,
    handleInputChange,
    handleGuestChange,
    addGuest,
    removeGuest,
    handleSubmit,
    handleDelete,
    handleStatusChange,
    resetForm
  };
};
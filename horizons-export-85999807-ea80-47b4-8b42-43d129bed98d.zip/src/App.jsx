import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import { AnimatePresence } from 'framer-motion';
import { Toaster } from '@/components/ui/toaster';
import { useMealRequests } from '@/hooks/useMealRequests';

import Layout from '@/components/layout/Layout';
import Header from '@/components/layout/Header';
import Dashboard from '@/components/dashboard/Dashboard';
import RequestList from '@/components/requests/RequestList';
import ManagerView from '@/components/manager/ManagerView';
import RequestForm from '@/components/requests/RequestForm';
import RequestView from '@/components/requests/RequestView';

function App() {
  const [activeTab, setActiveTab] = useState('dashboard');
  const [showRequestForm, setShowRequestForm] = useState(false);
  const [viewingRequest, setViewingRequest] = useState(null);

  const {
    requests,
    formData,
    editingRequest,
    stats,
    resetForm,
    handleInputChange,
    handleGuestChange,
    addGuest,
    removeGuest,
    handleSubmit,
    handleEdit,
    handleDelete,
    handleStatusChange,
    setEditingRequest,
  } = useMealRequests();

  const handleNewRequestClick = () => {
    resetForm();
    setShowRequestForm(true);
  };

  const handleEditClick = (request) => {
    handleEdit(request);
    setShowRequestForm(true);
  };

  const handleFormClose = () => {
    setShowRequestForm(false);
    if (editingRequest) {
      resetForm();
    }
  };

  const renderContent = () => {
    switch (activeTab) {
      case 'dashboard':
        return <Dashboard stats={stats} onNewRequestClick={handleNewRequestClick} />;
      case 'requests':
        return <RequestList requests={requests} onNewRequestClick={handleNewRequestClick} onEdit={handleEditClick} onDelete={handleDelete} onView={setViewingRequest} />;
      case 'manager':
        return <ManagerView requests={requests} onView={setViewingRequest} onStatusChange={handleStatusChange} />;
      default:
        return null;
    }
  };

  return (
    <>
      <Helmet>
        <title>Meal Invitation Management System</title>
        <meta name="description" content="Streamline your organization's meal invitation requests with our comprehensive management system" />
      </Helmet>
      
      <Layout>
        <Header />

        <div className="mb-8">
          <div className="flex justify-center mb-6">
            <div className="bg-white/10 backdrop-blur-md rounded-lg p-1">
              <button onClick={() => setActiveTab('dashboard')} className={`px-6 py-2 rounded-md transition-all ${activeTab === 'dashboard' ? 'bg-white text-purple-900 shadow-lg' : 'text-white hover:bg-white/20'}`}>
                Dashboard
              </button>
              <button onClick={() => setActiveTab('requests')} className={`px-6 py-2 rounded-md transition-all ${activeTab === 'requests' ? 'bg-white text-purple-900 shadow-lg' : 'text-white hover:bg-white/20'}`}>
                My Requests
              </button>
              <button onClick={() => setActiveTab('manager')} className={`px-6 py-2 rounded-md transition-all ${activeTab === 'manager' ? 'bg-white text-purple-900 shadow-lg' : 'text-white hover:bg-white/20'}`}>
                Manager View
              </button>
            </div>
          </div>

          <AnimatePresence mode="wait">
            {renderContent()}
          </AnimatePresence>
        </div>
      </Layout>

      {showRequestForm && (
        <RequestForm
          isOpen={showRequestForm}
          onClose={handleFormClose}
          formData={formData}
          handleInputChange={handleInputChange}
          handleGuestChange={handleGuestChange}
          addGuest={addGuest}
          removeGuest={removeGuest}
          handleSubmit={handleSubmit}
          editingRequest={editingRequest}
        />
      )}

      {viewingRequest && (
        <RequestView
          request={viewingRequest}
          onClose={() => setViewingRequest(null)}
          onStatusChange={handleStatusChange}
        />
      )}

      <Toaster />
    </>
  );
}

export default App;
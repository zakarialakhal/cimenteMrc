import React from 'react';
import { motion } from 'framer-motion';
import { Eye, CheckCircle, XCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { getStatusColor, getStatusIcon } from '@/lib/utils';

const ManagerRequestCard = ({ request, onView, onStatusChange }) => {
  const Icon = getStatusIcon(request.status);
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      whileHover={{ scale: 1.02 }}
      transition={{ duration: 0.2 }}
    >
      <Card className="bg-white/10 backdrop-blur-md border-white/20 hover:bg-white/15 transition-all">
        <div className="p-6">
          <div className="flex justify-between items-start mb-4">
            <div>
              <h3 className="text-lg font-semibold text-white mb-1">{request.requestingDepartment}</h3>
              <p className="text-purple-200 text-sm">Supervisor: {request.supervisorName}</p>
            </div>
            <Badge className={`${getStatusColor(request.status)} text-white border-0`}>
              <span className="flex items-center gap-1">
                <Icon className="w-4 h-4" />
                {request.status.charAt(0).toUpperCase() + request.status.slice(1)}
              </span>
            </Badge>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
            <div className="text-sm text-purple-200"><strong>Event Date:</strong> {new Date(request.eventDate).toLocaleDateString()}</div>
            <div className="text-sm text-purple-200"><strong>Guests:</strong> {request.guests.length}</div>
            <div className="text-sm text-purple-200"><strong>Meals:</strong> {request.mealsCount}</div>
          </div>

          <div className="flex gap-2">
            <Button size="sm" variant="outline" onClick={() => onView(request)} className="border-white/30 text-white hover:bg-white/20">
              <Eye className="w-4 h-4 mr-1" /> View Details
            </Button>
            {request.status === 'pending' && (
              <>
                <Button size="sm" onClick={() => onStatusChange(request.id, 'approved')} className="bg-green-500 hover:bg-green-600">
                  <CheckCircle className="w-4 h-4 mr-1" /> Approve
                </Button>
                <Button size="sm" variant="destructive" onClick={() => onStatusChange(request.id, 'rejected')}>
                  <XCircle className="w-4 h-4 mr-1" /> Reject
                </Button>
              </>
            )}
          </div>
        </div>
      </Card>
    </motion.div>
  );
};

export default ManagerRequestCard;
import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Card } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import ManagerRequestCard from '@/components/manager/ManagerRequestCard';

const ManagerView = ({ requests, onView, onStatusChange }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');

  const filteredRequests = requests
    .filter(req => {
      if (statusFilter === 'all') return true;
      return req.status === statusFilter;
    })
    .filter(req => 
      req.requestingDepartment.toLowerCase().includes(searchTerm.toLowerCase()) ||
      req.supervisorName.toLowerCase().includes(searchTerm.toLowerCase())
    );

  return (
    <motion.div
      key="manager"
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -20 }}
      transition={{ duration: 0.3 }}
    >
      <div className="flex flex-col md:flex-row justify-between items-center mb-6 gap-4">
        <h2 className="text-2xl font-bold text-white">Manager Dashboard</h2>
        <div className="flex gap-4 w-full md:w-auto">
          <Input 
            placeholder="Search requests..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="bg-white/10 border-white/20 text-white placeholder:text-white/60"
          />
          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="bg-white/10 border-white/20 text-white rounded-md h-10 px-3"
          >
            <option value="all">All Statuses</option>
            <option value="pending">Pending</option>
            <option value="approved">Approved</option>
            <option value="rejected">Rejected</option>
          </select>
        </div>
      </div>

      <div className="space-y-4">
        {filteredRequests.length === 0 ? (
          <Card className="bg-white/10 backdrop-blur-md border-white/20">
            <div className="p-8 text-center">
              <h3 className="text-xl font-semibold text-white mb-2">No matching requests found</h3>
              <p className="text-purple-200">Try adjusting your search or filter.</p>
            </div>
          </Card>
        ) : (
          filteredRequests.map((request) => (
            <ManagerRequestCard
              key={request.id}
              request={request}
              onView={onView}
              onStatusChange={onStatusChange}
            />
          ))
        )}
      </div>
    </motion.div>
  );
};

export default ManagerView;
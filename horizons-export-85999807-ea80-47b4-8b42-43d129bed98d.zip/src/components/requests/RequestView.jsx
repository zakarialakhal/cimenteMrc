import React from 'react';
import { motion } from 'framer-motion';
import { CheckCircle, XCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Dialog } from '@/components/ui/dialog';
import { getStatusColor, getStatusIcon } from '@/lib/utils';

const DetailItem = ({ label, value }) => (
  <div>
    <h3 className="font-semibold text-gray-700 mb-1">{label}</h3>
    <p className="text-gray-900">{value}</p>
  </div>
);

const CountItem = ({ label, value, color }) => (
  <div className={`text-center p-3 bg-${color}-50 rounded-lg`}>
    <p className={`text-2xl font-bold text-${color}-600`}>{value}</p>
    <p className={`text-sm text-${color}-800`}>{label}</p>
  </div>
);

const RequestView = ({ request, onClose, onStatusChange }) => {
  if (!request) return null;

  const Icon = getStatusIcon(request.status);

  return (
    <Dialog open={!!request} onOpenChange={onClose}>
      <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center p-4 z-50">
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          exit={{ opacity: 0, scale: 0.95 }}
          className="bg-white rounded-lg shadow-2xl max-w-3xl w-full max-h-[90vh] overflow-y-auto"
        >
          <div className="p-6">
            <div className="flex justify-between items-center mb-6">
              <h2 className="text-2xl font-bold text-gray-900">Request Details</h2>
              <Badge className={`${getStatusColor(request.status)} text-white border-0`}>
                <span className="flex items-center gap-1">
                  <Icon className="w-4 h-4" />
                  {request.status.charAt(0).toUpperCase() + request.status.slice(1)}
                </span>
              </Badge>
            </div>

            <div className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <DetailItem label="Requesting Department" value={request.requestingDepartment} />
                <DetailItem label="Supervisor" value={request.supervisorName} />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <DetailItem label="Event Date" value={new Date(request.eventDate).toLocaleDateString()} />
                {request.eventTime && <DetailItem label="Event Time" value={request.eventTime} />}
                {request.eventLocation && <DetailItem label="Location" value={request.eventLocation} />}
              </div>

              {request.eventPurpose && <DetailItem label="Event Purpose" value={request.eventPurpose} />}

              <div>
                <h3 className="font-semibold text-gray-700 mb-3">Invited Guests</h3>
                <div className="space-y-2">
                  {request.guests.map((guest, index) => (
                    <div key={index} className="flex justify-between items-center p-3 bg-gray-50 rounded-lg">
                      <span className="font-medium">{guest.name}</span>
                      <div className="flex items-center gap-2">
                        <Badge variant={guest.isInternal ? 'default' : 'secondary'}>
                          {guest.isInternal ? 'Internal' : 'External'}
                        </Badge>
                        {guest.organization && <span className="text-sm text-gray-600">{guest.organization}</span>}
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <CountItem label="Meals" value={request.mealsCount} color="blue" />
                <CountItem label="Desserts" value={request.dessertsCount} color="green" />
                <CountItem label="Soft Drinks" value={request.softDrinksCount} color="orange" />
                <CountItem label="Hot Beverages" value={request.hotBeveragesCount} color="purple" />
              </div>

              {request.specialRequests && (
                <div>
                  <h3 className="font-semibold text-gray-700 mb-1">Special Requests</h3>
                  <p className="text-gray-900 bg-gray-50 p-3 rounded-lg">{request.specialRequests}</p>
                </div>
              )}

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm text-gray-600">
                <div><strong>Submitted:</strong> {new Date(request.submittedAt).toLocaleString()}</div>
                <div><strong>Last Updated:</strong> {new Date(request.updatedAt).toLocaleString()}</div>
              </div>
            </div>

            <div className="flex gap-3 pt-6 mt-6 border-t">
              {request.status === 'pending' && (
                <>
                  <Button onClick={() => { onStatusChange(request.id, 'approved'); onClose(); }} className="bg-green-500 hover:bg-green-600 flex-1">
                    <CheckCircle className="w-4 h-4 mr-2" /> Approve
                  </Button>
                  <Button onClick={() => { onStatusChange(request.id, 'rejected'); onClose(); }} variant="destructive" className="flex-1">
                    <XCircle className="w-4 h-4 mr-2" /> Reject
                  </Button>
                </>
              )}
              <Button onClick={onClose} variant="outline" className="flex-1">
                Close
              </Button>
            </div>
          </div>
        </motion.div>
      </div>
    </Dialog>
  );
};

export default RequestView;
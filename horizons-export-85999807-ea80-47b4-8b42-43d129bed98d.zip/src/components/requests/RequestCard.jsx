import React from 'react';
import { motion } from 'framer-motion';
import { Eye, Edit, Trash2, Mail } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { useToast } from '@/components/ui/use-toast';
import { getStatusColor, getStatusIcon } from '@/lib/utils';

const RequestCard = ({ request, onEdit, onDelete, onView }) => {
  const { toast } = useToast();
  const Icon = getStatusIcon(request.status);

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      whileHover={{ scale: 1.02 }}
      transition={{ duration: 0.2 }}
    >
      <Card className="bg-white/10 backdrop-blur-md border-white/20 hover:bg-white/15 transition-all">
        <div className="p-6">
          <div className="flex justify-between items-start mb-4">
            <div>
              <h3 className="text-lg font-semibold text-white mb-1">{request.requestingDepartment}</h3>
              <p className="text-purple-200 text-sm">Supervisor: {request.supervisorName}</p>
            </div>
            <Badge className={`${getStatusColor(request.status)} text-white border-0`}>
              <span className="flex items-center gap-1">
                <Icon className="w-4 h-4" />
                {request.status.charAt(0).toUpperCase() + request.status.slice(1)}
              </span>
            </Badge>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
            <div className="text-sm text-purple-200"><strong>Event Date:</strong> {new Date(request.eventDate).toLocaleDateString()}</div>
            <div className="text-sm text-purple-200"><strong>Guests:</strong> {request.guests.length}</div>
            <div className="text-sm text-purple-200"><strong>Meals:</strong> {request.mealsCount}</div>
            <div className="text-sm text-purple-200"><strong>Submitted:</strong> {new Date(request.submittedAt).toLocaleDateString()}</div>
          </div>

          <div className="flex gap-2">
            <Button size="sm" variant="outline" onClick={() => onView(request)} className="border-white/30 text-white hover:bg-white/20">
              <Eye className="w-4 h-4 mr-1" /> View
            </Button>
            {request.status === 'pending' && (
              <>
                <Button size="sm" variant="outline" onClick={() => onEdit(request)} className="border-white/30 text-white hover:bg-white/20">
                  <Edit className="w-4 h-4 mr-1" /> Edit
                </Button>
                <Button size="sm" variant="outline" onClick={() => onDelete(request.id)} className="border-red-400 text-red-400 hover:bg-red-500/20">
                  <Trash2 className="w-4 h-4 mr-1" /> Delete
                </Button>
              </>
            )}
            <Button
              size="sm"
              variant="outline"
              onClick={() => toast({
                title: "🚧 Email Feature",
                description: "Email functionality isn't implemented yet—but don't worry! You can request it in your next prompt! 🚀"
              })}
              className="border-white/30 text-white hover:bg-white/20"
            >
              <Mail className="w-4 h-4 mr-1" /> Email
            </Button>
          </div>
        </div>
      </Card>
    </motion.div>
  );
};

export default RequestCard;
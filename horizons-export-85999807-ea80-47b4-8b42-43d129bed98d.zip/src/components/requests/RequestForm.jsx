import React from 'react';
import { motion } from 'framer-motion';
import { Plus, Trash2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select } from '@/components/ui/select';
import { Dialog } from '@/components/ui/dialog';

const RequestForm = ({
  isOpen,
  onClose,
  formData,
  handleInputChange,
  handleGuestChange,
  addGuest,
  removeGuest,
  handleSubmit,
  editingRequest,
}) => {
  const onSubmit = (e) => {
    const success = handleSubmit(e);
    if (success) {
      onClose();
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center p-4 z-50">
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          exit={{ opacity: 0, scale: 0.95 }}
          className="bg-white rounded-lg shadow-2xl max-w-4xl w-full max-h-[90vh] overflow-y-auto"
        >
          <div className="p-6">
            <h2 className="text-2xl font-bold text-gray-900 mb-6">
              {editingRequest ? 'Edit Meal Request' : 'New Meal Request'}
            </h2>

            <form onSubmit={onSubmit} className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="department">Requesting Department *</Label>
                  <Input id="department" value={formData.requestingDepartment} onChange={(e) => handleInputChange('requestingDepartment', e.target.value)} placeholder="Enter department name" required />
                </div>
                <div>
                  <Label htmlFor="supervisor">Supervisor Name *</Label>
                  <Input id="supervisor" value={formData.supervisorName} onChange={(e) => handleInputChange('supervisorName', e.target.value)} placeholder="Enter supervisor name" required />
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div>
                  <Label htmlFor="eventDate">Event Date *</Label>
                  <Input id="eventDate" type="date" value={formData.eventDate} onChange={(e) => handleInputChange('eventDate', e.target.value)} required />
                </div>
                <div>
                  <Label htmlFor="eventTime">Event Time</Label>
                  <Input id="eventTime" type="time" value={formData.eventTime} onChange={(e) => handleInputChange('eventTime', e.target.value)} />
                </div>
                <div>
                  <Label htmlFor="eventLocation">Event Location</Label>
                  <Input id="eventLocation" value={formData.eventLocation} onChange={(e) => handleInputChange('eventLocation', e.target.value)} placeholder="Enter location" />
                </div>
              </div>

              <div>
                <Label htmlFor="eventPurpose">Event Purpose</Label>
                <Input id="eventPurpose" value={formData.eventPurpose} onChange={(e) => handleInputChange('eventPurpose', e.target.value)} placeholder="Brief description of the event" />
              </div>

              <div>
                <div className="flex justify-between items-center mb-4">
                  <Label>Invited Guests</Label>
                  <Button type="button" onClick={addGuest} size="sm" className="bg-purple-500 hover:bg-purple-600">
                    <Plus className="w-4 h-4 mr-1" /> Add Guest
                  </Button>
                </div>
                <div className="space-y-3">
                  {formData.guests.map((guest, index) => (
                    <div key={index} className="grid grid-cols-1 md:grid-cols-4 gap-3 p-4 bg-gray-50 rounded-lg">
                      <div>
                        <Label>Guest Name</Label>
                        <Input value={guest.name} onChange={(e) => handleGuestChange(index, 'name', e.target.value)} placeholder="Full name" />
                      </div>
                      <div>
                        <Label>Type</Label>
                        <Select value={guest.isInternal ? 'internal' : 'external'} onValueChange={(value) => handleGuestChange(index, 'isInternal', value === 'internal')}>
                          <option value="internal">Internal</option>
                          <option value="external">External</option>
                        </Select>
                      </div>
                      <div>
                        <Label>{guest.isInternal ? 'Unit/Department' : 'Organization'}</Label>
                        <Input value={guest.organization} onChange={(e) => handleGuestChange(index, 'organization', e.target.value)} placeholder={guest.isInternal ? 'Unit name' : 'Organization name'} />
                      </div>
                      <div className="flex items-end">
                        {formData.guests.length > 1 && (
                          <Button type="button" onClick={() => removeGuest(index)} size="sm" variant="outline" className="text-red-500 border-red-300 hover:bg-red-50">
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <div>
                  <Label htmlFor="meals">Number of Meals</Label>
                  <Input id="meals" type="number" min="1" value={formData.mealsCount} onChange={(e) => handleInputChange('mealsCount', parseInt(e.target.value) || 1)} />
                </div>
                <div>
                  <Label htmlFor="desserts">Desserts</Label>
                  <Input id="desserts" type="number" min="0" value={formData.dessertsCount} onChange={(e) => handleInputChange('dessertsCount', parseInt(e.target.value) || 0)} />
                </div>
                <div>
                  <Label htmlFor="drinks">Soft Drinks</Label>
                  <Input id="drinks" type="number" min="0" value={formData.softDrinksCount} onChange={(e) => handleInputChange('softDrinksCount', parseInt(e.target.value) || 0)} />
                </div>
                <div>
                  <Label htmlFor="beverages">Hot Beverages</Label>
                  <Input id="beverages" type="number" min="0" value={formData.hotBeveragesCount} onChange={(e) => handleInputChange('hotBeveragesCount', parseInt(e.target.value) || 0)} />
                </div>
              </div>

              <div>
                <Label htmlFor="special">Special Requests</Label>
                <textarea id="special" value={formData.specialRequests} onChange={(e) => handleInputChange('specialRequests', e.target.value)} placeholder="Any dietary restrictions, special arrangements, etc." className="w-full p-3 border border-gray-300 rounded-md focus:ring-2 focus:ring-purple-500 focus:border-transparent" rows="3" />
              </div>

              <div className="flex gap-3 pt-4">
                <Button type="submit" className="bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600 flex-1">
                  {editingRequest ? 'Update Request' : 'Submit Request'}
                </Button>
                <Button type="button" variant="outline" onClick={onClose} className="flex-1">
                  Cancel
                </Button>
              </div>
            </form>
          </div>
        </motion.div>
      </div>
    </Dialog>
  );
};

export default RequestForm;
import React from 'react';
import { motion } from 'framer-motion';
import { Calendar, Plus } from 'lucide-react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import RequestCard from './RequestCard';
import { useToast } from '@/components/ui/use-toast';

const RequestsList = ({ requests, onNewRequest, onEdit, onDelete, onView }) => {
  const { toast } = useToast();

  const handleEmailClick = () => {
     toast({
        title: "🚧 Email Feature",
        description: "Email functionality isn't implemented yet—but don't worry! You can request it in your next prompt! 🚀"
     });
  };

  return (
    <motion.div
      key="requests"
      initial={{ opacity: 0, x: 20 }}
      animate={{ opacity: 1, x: 0 }}
      exit={{ opacity: 0, x: -20 }}
      transition={{ duration: 0.3 }}
    >
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-2xl font-bold text-white">My Requests</h2>
        <Button
          onClick={onNewRequest}
          className="bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600"
        >
          <Plus className="w-4 h-4 mr-2" />
          New Request
        </Button>
      </div>

      <div className="space-y-4">
        {requests.length === 0 ? (
          <Card className="bg-white/10 backdrop-blur-md border-white/20">
            <div className="p-8 text-center">
              <Calendar className="w-16 h-16 text-purple-300 mx-auto mb-4" />
              <h3 className="text-xl font-semibold text-white mb-2">No Requests Yet</h3>
              <p className="text-purple-200 mb-4">Start by creating your first meal request</p>
              <Button
                onClick={onNewRequest}
                className="bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600"
              >
                Create Request
              </Button>
            </div>
          </Card>
        ) : (
          requests.map((request) => (
            <RequestCard 
              key={request.id}
              request={request}
              onEdit={onEdit}
              onDelete={onDelete}
              onView={onView}
              onEmail={handleEmailClick}
            />
          ))
        )}
      </div>
    </motion.div>
  );
};

export default RequestsList;
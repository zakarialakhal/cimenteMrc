import React from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Dialog } from '@/components/ui/dialog';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { CheckCircle, XCircle, AlertCircle } from 'lucide-react';

const getStatusAttributes = (status) => {
  switch (status) {
    case 'approved': return { color: 'bg-green-500', icon: <CheckCircle className="w-4 h-4" /> };
    case 'rejected': return { color: 'bg-red-500', icon: <XCircle className="w-4 h-4" /> };
    default: return { color: 'bg-yellow-500', icon: <AlertCircle className="w-4 h-4" /> };
  }
};

const ViewRequestDialog = ({ request, onOpenChange, onStatusChange }) => {
  const isOpen = !!request;
  const { color, icon } = getStatusAttributes(request?.status);

  return (
    <Dialog open={isOpen} onOpenChange={onOpenChange}>
      <AnimatePresence>
        {isOpen && (
          <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center p-4 z-50">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="bg-white rounded-lg shadow-2xl max-w-3xl w-full max-h-[90vh] overflow-y-auto"
            >
              <div className="p-6">
                <div className="flex justify-between items-center mb-6">
                  <h2 className="text-2xl font-bold text-gray-900">Request Details</h2>
                  {request && (
                    <Badge className={`${color} text-white border-0`}>
                      <span className="flex items-center gap-1">
                        {icon}
                        {request.status.charAt(0).toUpperCase() + request.status.slice(1)}
                      </span>
                    </Badge>
                  )}
                </div>
                {request && (
                <div className="space-y-6">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <h3 className="font-semibold text-gray-700 mb-1">Requesting Department</h3>
                        <p className="text-gray-900">{request.requestingDepartment}</p>
                      </div>
                      <div>
                        <h3 className="font-semibold text-gray-700 mb-1">Supervisor</h3>
                        <p className="text-gray-900">{request.supervisorName}</p>
                      </div>
                    </div>
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                      <div>
                        <h3 className="font-semibold text-gray-700 mb-1">Event Date</h3>
                        <p className="text-gray-900">{new Date(request.eventDate).toLocaleDateString()}</p>
                      </div>
                      {request.eventTime && (
                        <div>
                          <h3 className="font-semibold text-gray-700 mb-1">Event Time</h3>
                          <p className="text-gray-900">{request.eventTime}</p>
                        </div>
                      )}
                      {request.eventLocation && (
                        <div>
                          <h3 className="font-semibold text-gray-700 mb-1">Location</h3>
                          <p className="text-gray-900">{request.eventLocation}</p>
                        </div>
                      )}
                    </div>
                    {request.eventPurpose && (
                      <div>
                        <h3 className="font-semibold text-gray-700 mb-1">Event Purpose</h3>
                        <p className="text-gray-900">{request.eventPurpose}</p>
                      </div>
                    )}
                    <div>
                      <h3 className="font-semibold text-gray-700 mb-3">Invited Guests</h3>
                      <div className="space-y-2">
                        {request.guests.map((guest, index) => (
                          <div key={index} className="flex justify-between items-center p-3 bg-gray-50 rounded-lg">
                            <span className="font-medium">{guest.name}</span>
                            <div className="flex items-center gap-2">
                              <Badge variant={guest.isInternal ? 'default' : 'secondary'}>
                                {guest.isInternal ? 'Internal' : 'External'}
                              </Badge>
                              {guest.organization && (
                                <span className="text-sm text-gray-600">{guest.organization}</span>
                              )}
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                      <div className="text-center p-3 bg-blue-50 rounded-lg"><p className="text-2xl font-bold text-blue-600">{request.mealsCount}</p><p className="text-sm text-blue-800">Meals</p></div>
                      <div className="text-center p-3 bg-green-50 rounded-lg"><p className="text-2xl font-bold text-green-600">{request.dessertsCount}</p><p className="text-sm text-green-800">Desserts</p></div>
                      <div className="text-center p-3 bg-orange-50 rounded-lg"><p className="text-2xl font-bold text-orange-600">{request.softDrinksCount}</p><p className="text-sm text-orange-800">Soft Drinks</p></div>
                      <div className="text-center p-3 bg-purple-50 rounded-lg"><p className="text-2xl font-bold text-purple-600">{request.hotBeveragesCount}</p><p className="text-sm text-purple-800">Hot Beverages</p></div>
                    </div>
                    {request.specialRequests && (
                      <div>
                        <h3 className="font-semibold text-gray-700 mb-1">Special Requests</h3>
                        <p className="text-gray-900 bg-gray-50 p-3 rounded-lg">{request.specialRequests}</p>
                      </div>
                    )}
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm text-gray-600">
                      <div><strong>Submitted:</strong> {new Date(request.submittedAt).toLocaleString()}</div>
                      <div><strong>Last Updated:</strong> {new Date(request.updatedAt).toLocaleString()}</div>
                    </div>
                  </div>
                  )}
                  <div className="flex gap-3 pt-6 mt-6 border-t">
                    {request && request.status === 'pending' && (
                      <>
                        <Button onClick={() => onStatusChange(request.id, 'approved')} className="bg-green-500 hover:bg-green-600 flex-1"><CheckCircle className="w-4 h-4 mr-2" />Approve</Button>
                        <Button onClick={() => onStatusChange(request.id, 'rejected')} variant="destructive" className="flex-1"><XCircle className="w-4 h-4 mr-2" />Reject</Button>
                      </>
                    )}
                    <Button onClick={() => onOpenChange(null)} variant="outline" className="flex-1">Close</Button>
                  </div>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </Dialog>
  );
};

export default ViewRequestDialog;
import React from 'react';
import { motion } from 'framer-motion';

const Header = () => {
  return (
    <motion.div
      initial={{ opacity: 0, y: -20 }}
      animate={{ opacity: 1, y: 0 }}
      className="text-center mb-8"
    >
      <h1 className="text-4xl font-bold text-white mb-2">
        Meal Invitation Management
      </h1>
      <p className="text-purple-200 text-lg">
        Streamline your organization's meal requests
      </p>
    </motion.div>
  );
};

export default Header;
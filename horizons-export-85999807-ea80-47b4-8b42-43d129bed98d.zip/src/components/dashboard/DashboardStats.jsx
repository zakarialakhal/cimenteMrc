import React from 'react';
import { Card } from '@/components/ui/card';
import { Users, Clock, CheckCircle, XCircle } from 'lucide-react';

const StatCard = ({ title, value, icon, gradient }) => (
  <Card className={`${gradient} border-0 text-white`}>
    <div className="p-6">
      <div className="flex items-center justify-between">
        <div>
          <p className="text-sm opacity-80">{title}</p>
          <p className="text-3xl font-bold">{value}</p>
        </div>
        {icon}
      </div>
    </div>
  </Card>
);

const DashboardStats = ({ stats }) => {
  return (
    <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
      <StatCard 
        title="Total Requests" 
        value={stats.total} 
        icon={<Users className="w-8 h-8 text-blue-200" />} 
        gradient="bg-gradient-to-br from-blue-500 to-blue-600"
      />
      <StatCard 
        title="Pending" 
        value={stats.pending} 
        icon={<Clock className="w-8 h-8 text-yellow-200" />} 
        gradient="bg-gradient-to-br from-yellow-500 to-orange-500"
      />
      <StatCard 
        title="Approved" 
        value={stats.approved} 
        icon={<CheckCircle className="w-8 h-8 text-green-200" />} 
        gradient="bg-gradient-to-br from-green-500 to-green-600"
      />
      <StatCard 
        title="Rejected" 
        value={stats.rejected} 
        icon={<XCircle className="w-8 h-8 text-red-200" />} 
        gradient="bg-gradient-to-br from-red-500 to-red-600"
      />
    </div>
  );
};

export default DashboardStats;
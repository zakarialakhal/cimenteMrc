import React from 'react';
import { motion } from 'framer-motion';
import { Plus } from 'lucide-react';
import { Button } from '@/components/ui/button';
import DashboardStats from '@/components/dashboard/DashboardStats';

const Dashboard = ({ stats, onNewRequestClick }) => {
  return (
    <motion.div
      key="dashboard"
      initial={{ opacity: 0, x: -20 }}
      animate={{ opacity: 1, x: 0 }}
      exit={{ opacity: 0, x: 20 }}
      transition={{ duration: 0.3 }}
    >
      <DashboardStats stats={stats} />
      <div className="text-center">
        <Button
          onClick={onNewRequestClick}
          size="lg"
          className="bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600 text-white px-8 py-3 text-lg"
        >
          <Plus className="w-5 h-5 mr-2" />
          New Meal Request
        </Button>
      </div>
    </motion.div>
  );
};

export default Dashboard;
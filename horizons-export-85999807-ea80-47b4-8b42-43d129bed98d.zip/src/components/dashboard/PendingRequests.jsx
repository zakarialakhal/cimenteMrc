import React from 'react';
import { motion } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { CheckCircle, Clock, Eye, User, Users, XCircle } from 'lucide-react';

const PendingRequests = ({ requests, onStatusChange, onView }) => {
  const pendingRequests = requests.filter(r => r.status === 'pending');

  if (pendingRequests.length === 0) {
    return (
      <Card className="bg-white/10 backdrop-blur-md border-white/20 mt-8">
        <div className="p-8 text-center text-white">
          <CheckCircle className="w-16 h-16 text-green-400 mx-auto mb-4" />
          <h3 className="text-xl font-semibold mb-2">All Clear!</h3>
          <p className="text-purple-200">There are no pending requests to review.</p>
        </div>
      </Card>
    );
  }

  return (
    <div className="mt-8">
      <h2 className="text-2xl font-bold text-white mb-4">Pending Approvals</h2>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {pendingRequests.map((request, index) => (
          <motion.div
            key={request.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.1 }}
          >
            <Card className="bg-white/10 backdrop-blur-md border-white/20 text-white hover:bg-white/15 transition-all h-full flex flex-col">
              <CardHeader>
                <CardTitle className="text-lg truncate">{request.requestingDepartment}</CardTitle>
                <div className="text-xs text-purple-300 pt-1 flex items-center">
                  <User className="w-3 h-3 mr-1.5" />
                  Supervisor: {request.supervisorName}
                </div>
              </CardHeader>
              <CardContent className="flex-grow">
                <div className="text-sm text-purple-200 space-y-2">
                  <div className="flex items-center">
                    <Clock className="w-4 h-4 mr-2" />
                    <span>{new Date(request.eventDate).toLocaleDateString()}</span>
                  </div>
                  <div className="flex items-center">
                    <Users className="w-4 h-4 mr-2" />
                    <span>{request.guests.length} Guests</span>
                  </div>
                </div>
              </CardContent>
              <div className="p-4 pt-0 flex gap-2 justify-end">
                <Button size="sm" variant="outline" className="border-green-400 text-green-400 hover:bg-green-500/20 hover:text-green-300" onClick={() => onStatusChange(request.id, 'approved')}>
                  <CheckCircle className="w-4 h-4" />
                </Button>
                <Button size="sm" variant="outline" className="border-red-400 text-red-400 hover:bg-red-500/20 hover:text-red-300" onClick={() => onStatusChange(request.id, 'rejected')}>
                  <XCircle className="w-4 h-4" />
                </Button>
                <Button size="sm" variant="outline" className="border-white/30 text-white hover:bg-white/20" onClick={() => onView(request)}>
                  <Eye className="w-4 h-4" />
                </Button>
              </div>
            </Card>
          </motion.div>
        ))}
      </div>
    </div>
  );
};

export default PendingRequests;
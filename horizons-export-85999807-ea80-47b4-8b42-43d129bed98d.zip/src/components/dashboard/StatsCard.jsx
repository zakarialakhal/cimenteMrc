import React from 'react';
import { Card } from '@/components/ui/card';
import { motion } from 'framer-motion';

const StatsCard = ({ title, value, icon, gradient }) => (
  <motion.div whileHover={{ y: -5 }}>
    <Card className={`${gradient} border-0 text-white`}>
      <div className="p-6">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-sm opacity-80">{title}</p>
            <p className="text-3xl font-bold">{value}</p>
          </div>
          {icon}
        </div>
      </div>
    </Card>
  </motion.div>
);

export default StatsCard;